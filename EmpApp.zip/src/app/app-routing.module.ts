import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeListComponent } from './employee/employee-list.component';
import { AddEmployeeComponent } from './employee/add-employee.component';
import { HomeComponent } from './employee/home.component';
import { EmployeeComponent } from './employee/employee.component';
import { SearchEmployeeComponent } from './employee/search-employee.component';
import { AddEmployeeCanDeactivateRouteGuardService } from './employee/add-employee-can-deactivate-route-guard.service';



const routes: Routes = [
  {path:"employees",component:EmployeeListComponent},//route path & component
  {path:"add",component:AddEmployeeComponent, canDeactivate:[AddEmployeeCanDeactivateRouteGuardService]},
  {path:"employees/:id",component:EmployeeComponent},
  {path:"search",component:SearchEmployeeComponent},
  {path:"",component:HomeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
