import { Component, OnInit, Input, EventEmitter, Output} from '@angular/core';

@Component({
  selector: 'app-employee-count',
  templateUrl: './employee-count.component.html',
  styleUrls: ['./employee-count.component.css']
})
export class EmployeeCountComponent implements OnInit {

  selectedradioButtonValue:string="all";
  @Output()
  countRadioButtonvalueChange:EventEmitter<string>=new EventEmitter <string>();

  @Input()
  all: number;
  @Input()
  male: number;
  @Input()
  female: number;
  constructor() { }

  ngOnInit() {
  }

  countRadioButtonvalueChanged()
  {
    this.countRadioButtonvalueChange.emit(this.selectedradioButtonValue);
  }

}

