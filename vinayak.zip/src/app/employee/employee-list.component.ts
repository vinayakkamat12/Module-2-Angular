import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { EmployeeService } from './employee.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css'],
  providers:[EmployeeService]
})
export class EmployeeListComponent implements OnInit {
  searchTerm:string;
  employee:any[];
  selectedRadioButtonvalue:string="all";
  @Output()
  countRadioButtonValueChange:EventEmitter<string>= new EventEmitter<string>();

  constructor(private employeeService:EmployeeService) { }

  

  getAllEmployeesCount():number{
    return this.employee.length;
  }

  getMaleEmployeesCount():number{
    return this.employee.filter(e=>e.gender==='Male').length;
  }

  getFemaleEmployeesCount():number{
    return this.employee.filter(e=>e.gender==='Female').length;
  }

  ngOnInit() {
    this.employee=this.employeeService.getEmployees();
    console.log(this.employee);
  }

  countRadioButtonValueChanged(value:string) {
    this.countRadioButtonValueChange.emit(this.selectedRadioButtonvalue)
  }

}
