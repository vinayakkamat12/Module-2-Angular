import { ChangeCaseDirective } from './change-case.directive';

describe('ChangeCaseDirective', () => {
  it('should create an instance', () => {
    const directive = new ChangeCaseDirective();
    expect(directive).toBeTruthy();
  });
});
