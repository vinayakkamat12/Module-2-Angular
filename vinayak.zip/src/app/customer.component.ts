import { Component } from "@angular/core";

@Component({
    selector:"myCustomer",
    template:'<h1>Welcome to Customer Component</h1>',
    styles:['h1{color:red}']
}
)
export class CustomerComponent {

}