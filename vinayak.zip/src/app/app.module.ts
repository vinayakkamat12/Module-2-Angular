import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import {FormsModule} from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { EmployeeListComponent } from './employee/employee-list.component';
import { EmpComponent } from './emp/emp.component';
import { EmployeeCountComponent } from './employee/employee-count.component';
import { ChangeCaseDirective } from './change-case.directive';
import { DemoDirective } from './demo.directive';
import { EmployeeTitlePipe } from './employee-title.pipe';
import { EmployeeFilterPipe } from './employee-filter.pipe';
import { EmployeeService } from './employee/employee.service';
import {ReactiveFormsModule} from '@angular/forms'

@NgModule({
  declarations: [
    AppComponent,
    EmployeeListComponent,
    EmpComponent,
    EmployeeCountComponent,
    ChangeCaseDirective,
    DemoDirective,
    EmployeeTitlePipe,
    EmployeeFilterPipe,
    
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
  ],

  providers: [EmployeeService],
  bootstrap: [AppComponent]
})
export class AppModule { }
