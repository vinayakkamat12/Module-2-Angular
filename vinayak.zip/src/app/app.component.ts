import { Component } from '@angular/core';
import {FormGroup, FormControl, Validators, FormBuilder} from '@angular/forms';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  // userForm:FormGroup=new FormGroup ({
  //   name:new FormControl("Vinayak",[Validators.required,Validators.minLength(4),Validators.maxLength(10)]),
  //   email:new FormControl(),
  //   address:new FormGroup({
  //     street:new FormControl(),
  //     city:new FormControl(),
  //     pincode:new FormControl(null, Validators.pattern("[1-9][0-9]{5}"))
    userForm:FormGroup;
    constructor(private formBuilder: FormBuilder) {

    }

  //   })
  // });
   
  // processData(event) {
  //   this.name=event.target.value;
    
  // }
  ngOnInit() {
    this.userForm=this.formBuilder.group({
      name:['Reni',[Validators.required,Validators.minLength(4),Validators.maxLength(10)]],
      email:[],
      address:this.formBuilder.group({
        street:[],
        city:[],
        pincode:[]
      })
    }
    )
  }

  process() {
    console.log(this.userForm.value);
  }

  processForm(value:any)
  {
    // this.name=event.target.value;
    console.log(value);
  }
  
  day:number=1;
  content:string="Hello World";

  
}
