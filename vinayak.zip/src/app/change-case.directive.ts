import { Directive, ElementRef, Renderer, HostListener } from '@angular/core';

@Directive({
  selector: '[appChangeCase]'
})
export class ChangeCaseDirective {

  constructor(private el:ElementRef,private renderer:Renderer) { }

  @HostListener('blur')
  onblur() {
    let changedvalue=this.el.nativeElement.value.toUpperCase();
    this.renderer.setElementProperty(this.el.nativeElement,'value',changedvalue);
  }


}
